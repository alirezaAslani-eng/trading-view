import { SvgIcon, SvgIconProps } from "@mui/material";

function UserGuardIcon(props: SvgIconProps) {
  return (
    <SvgIcon
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M10.4899 2.22957L5.49991 4.09957C4.34991 4.52957 3.40991 5.88955 3.40991 7.11955V14.5495C3.40991 15.7295 4.18992 17.2795 5.13992 17.9895L9.43991 21.1996C10.8499 22.2596 13.1699 22.2596 14.5799 21.1996L18.8799 17.9895C19.8299 17.2795 20.6099 15.7295 20.6099 14.5495V7.11955C20.6099 5.88955 19.6699 4.52957 18.5199 4.09957L13.5299 2.22957C12.6799 1.91957 11.3199 1.91957 10.4899 2.22957Z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M11.9999 10.9204C11.9599 10.9204 11.9099 10.9204 11.8699 10.9204C10.9299 10.8904 10.1799 10.1104 10.1799 9.1604C10.1799 8.1904 10.9699 7.40039 11.9399 7.40039C12.9099 7.40039 13.7 8.1904 13.7 9.1604C13.69 10.1204 12.9399 10.8904 11.9999 10.9204Z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.01 13.7204C9.05004 14.3604 9.05004 15.4103 10.01 16.0503C11.1 16.7803 12.89 16.7803 13.98 16.0503C14.94 15.4103 14.94 14.3604 13.98 13.7204C12.9 12.9904 11.11 12.9904 10.01 13.7204Z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </SvgIcon>
  );
}

export default UserGuardIcon;
