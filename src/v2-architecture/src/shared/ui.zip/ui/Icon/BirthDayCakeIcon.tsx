import { SvgIcon, SvgIconProps } from "@mui/material";

function BirthDayCakeIcon(props: SvgIconProps) {
  return (
    <SvgIcon
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M2 22H22"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.11011 22V13C3.11011 11.34 4.60011 10 6.44011 10H17.5501C19.3901 10 20.8801 11.34 20.8801 13V22"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.56006 10V7.17C5.56006 5.97 6.64006 5 7.98006 5H16.0301C17.3601 5 18.4401 5.97 18.4401 7.17V10"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.53003 13.9805L3.90003 13.9905C4.64003 14.0005 5.23003 14.6005 5.23003 15.3405V15.6705C5.23003 16.4105 5.83003 17.0205 6.58003 17.0205C7.32003 17.0205 7.93003 16.4205 7.93003 15.6705V15.3605C7.93003 14.6205 8.53003 14.0105 9.28003 14.0105C10.02 14.0105 10.63 14.6105 10.63 15.3605V15.6705C10.63 16.4105 11.23 17.0205 11.98 17.0205C12.72 17.0205 13.33 16.4205 13.33 15.6705V15.3605C13.33 14.6205 13.93 14.0105 14.68 14.0105C15.42 14.0105 16.03 14.6105 16.03 15.3605V15.6705C16.03 16.4105 16.63 17.0205 17.38 17.0205C18.12 17.0205 18.73 16.4205 18.73 15.6705V15.3605C18.73 14.6205 19.33 14.0105 20.08 14.0105H20.53"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 5V3"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16 5V3"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 5V2"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </SvgIcon>
  );
}

export default BirthDayCakeIcon;
