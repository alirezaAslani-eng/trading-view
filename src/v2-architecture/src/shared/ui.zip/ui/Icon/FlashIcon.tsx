import { SvgIcon, SvgIconProps } from "@mui/material";

function FlashIcon(props: SvgIconProps) {
  return (
    <SvgIcon viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        stroke="currentColor"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M5.07492 11.0667H7.64992V17.0667C7.64992 18.4667 8.40826 18.7501 9.33326 17.7001L15.6416 10.5334C16.4166 9.65841 16.0916 8.93341 14.9166 8.93341H12.3416V2.93341C12.3416 1.53341 11.5833 1.25008 10.6583 2.30008L4.34992 9.46674C3.58326 10.3501 3.90826 11.0667 5.07492 11.0667Z"
      />
    </SvgIcon>
  );
}
export default FlashIcon;
